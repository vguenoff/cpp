int numGlobal;

int main() {
    int num;
    num = 5;
    int sameNum(5);
    return 0;
}
