#include <iostream>

int main() {
    int arrInt[5];
    char arrChar[10];

    std::cout << "sizeof array ints: " << sizeof(arrInt) << std::endl;
    std::cout << "sizeof array chars: " << sizeof(arrChar) << std::endl;

    return 0;
}
